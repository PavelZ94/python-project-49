### Hexlet tests and linter status:
[![Actions Status](https://github.com/PavelZ94/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/PavelZ94/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/663116eda1270bd6ca0b/maintainability)](https://codeclimate.com/github/PavelZ94/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/Uvr9AEK5RK7U5A6Nk5CWvl6x6.svg)](https://asciinema.org/a/Uvr9AEK5RK7U5A6Nk5CWvl6x6)
